# PyCodeObfuscator
 A python program that obuscates python ciode (makes it less readable) DO NOT USE THIS FOR MALICIOUS PURPOUSES
